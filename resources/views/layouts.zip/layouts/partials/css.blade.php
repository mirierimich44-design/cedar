<link href="{{ asset('css/tailwind/app.css?v='.$asset_v) }}" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('css/vendor.css?v='.$asset_v) }}">

@if( in_array(session()->get('user.language', config('app.locale')), config('constants.langs_rtl')) )
	<link rel="stylesheet" href="{{ asset('css/rtl.css?v='.$asset_v) }}">
@endif

@yield('css')

<!-- app css -->
<link rel="stylesheet" href="{{ asset('css/app.css?v='.$asset_v) }}">

<!-- Modern Theme -->
<link rel="stylesheet" href="{{ asset('css/modern-theme.css?v='.$asset_v) }}">
<link rel="stylesheet" href="{{ asset('css/modern-minimal.css?v='.$asset_v) }}">
<link rel="stylesheet" href="{{ asset('css/backend-material.css?v='.$asset_v) }}">

<!-- Dynamic Theme Color CSS Variables -->
@php
$__tc = session('business.theme_color', 'primary');
$__themeVars = [
    'primary' => [
        'main'   => '#4f46e5', 'hover'  => '#4338ca',
        'light'  => '#818cf8', 'dark'   => '#3730a3',
        'subtle' => '#eef2ff', 'border' => '#c7d2fe',
        'ring'   => '#a5b4fc',
    ],
    'purple' => [
        'main'   => '#9333ea', 'hover'  => '#7c3aed',
        'light'  => '#c084fc', 'dark'   => '#6d28d9',
        'subtle' => '#faf5ff', 'border' => '#ddd6fe',
        'ring'   => '#d8b4fe',
    ],
    'green' => [
        'main'   => '#059669', 'hover'  => '#047857',
        'light'  => '#34d399', 'dark'   => '#065f46',
        'subtle' => '#ecfdf5', 'border' => '#a7f3d0',
        'ring'   => '#6ee7b7',
    ],
    'red' => [
        'main'   => '#dc2626', 'hover'  => '#b91c1c',
        'light'  => '#f87171', 'dark'   => '#991b1b',
        'subtle' => '#fef2f2', 'border' => '#fecaca',
        'ring'   => '#fca5a5',
    ],
    'yellow' => [
        'main'   => '#d97706', 'hover'  => '#b45309',
        'light'  => '#fbbf24', 'dark'   => '#92400e',
        'subtle' => '#fffbeb', 'border' => '#fde68a',
        'ring'   => '#fcd34d',
    ],
    'orange' => [
        'main'   => '#ea580c', 'hover'  => '#c2410c',
        'light'  => '#fb923c', 'dark'   => '#9a3412',
        'subtle' => '#fff7ed', 'border' => '#fed7aa',
        'ring'   => '#fdba74',
    ],
    'sky' => [
        'main'   => '#0284c7', 'hover'  => '#0369a1',
        'light'  => '#38bdf8', 'dark'   => '#075985',
        'subtle' => '#f0f9ff', 'border' => '#bae6fd',
        'ring'   => '#7dd3fc',
    ],
];
$__cv = $__themeVars[$__tc] ?? $__themeVars['primary'];
@endphp
<style>
:root {
    /* pos-material / backend-material tokens */
    --pos-primary:        {{ $__cv['main'] }};
    --pos-primary-light:  {{ $__cv['light'] }};
    --pos-primary-dark:   {{ $__cv['dark'] }};
    --pos-primary-subtle: {{ $__cv['subtle'] }};
    /* modern-theme tokens */
    --primary:            {{ $__cv['main'] }};
    --primary-hover:      {{ $__cv['hover'] }};
    --primary-light:      {{ $__cv['subtle'] }};
    /* modern-minimal tokens */
    --primary-modern:       {{ $__cv['main'] }};
    --primary-modern-hover: {{ $__cv['hover'] }};
    /* shared accent helpers */
    --theme-main:   {{ $__cv['main'] }};
    --theme-hover:  {{ $__cv['hover'] }};
    --theme-light:  {{ $__cv['light'] }};
    --theme-dark:   {{ $__cv['dark'] }};
    --theme-subtle: {{ $__cv['subtle'] }};
    --theme-border: {{ $__cv['border'] }};
    --theme-ring:   {{ $__cv['ring'] }};
}

/* ─── Header buttons (sidebar toggles, dropdowns) ─── */
.header-theme-btn {
    background-color: var(--theme-dark) !important;
    color: white !important;
}
.header-theme-btn:hover,
.header-theme-btn:focus {
    background-color: var(--theme-hover) !important;
    color: white !important;
}

/* ─── Override hardcoded indigo/blue gradient buttons system-wide ─── */
.tw-from-indigo-600.tw-to-blue-500,
.tw-from-indigo-500.tw-to-blue-500,
.tw-from-indigo-600.tw-to-blue-600 {
    background-image: linear-gradient(to right, var(--theme-dark), var(--theme-main)) !important;
}
.hover\:tw-from-indigo-600:hover,
.hover\:tw-from-indigo-700:hover {
    background-image: linear-gradient(to right, var(--theme-hover), var(--theme-main)) !important;
}

/* ─── Override hardcoded blue step-indicator badges ─── */
.tw-bg-blue-600 {
    background-color: var(--theme-main) !important;
}
.tw-border-blue-400, .tw-border-blue-500 {
    border-color: var(--theme-main) !important;
}
.tw-text-blue-600, .tw-text-blue-700, .tw-text-indigo-600 {
    color: var(--theme-main) !important;
}
.focus\:tw-ring-blue-500:focus {
    --tw-ring-color: var(--theme-ring) !important;
}
</style>

<!-- Dark Mode -->
<style>
body.dark-mode,.dark-mode .content-wrapper,.dark-mode main{background:#0f172a!important;color:#e2e8f0!important}
.dark-mode .box,.dark-mode .box-body,.dark-mode .card,.dark-mode .panel{background:#1e293b!important;border-color:rgba(255,255,255,0.07)!important;color:#e2e8f0!important}
.dark-mode .box-header,.dark-mode .card-header{background:#1e293b!important;border-bottom-color:rgba(255,255,255,0.1)!important}
.dark-mode table.table,.dark-mode table.dataTable{background:#1e293b!important;color:#e2e8f0!important}
.dark-mode table.table thead th,.dark-mode table.dataTable thead th{background:#0f172a!important;color:#94a3b8!important;border-bottom-color:rgba(255,255,255,0.1)!important}
.dark-mode table.table tbody td,.dark-mode table.dataTable tbody td{border-bottom-color:rgba(255,255,255,0.05)!important;color:#cbd5e1!important;background:#1e293b!important}
.dark-mode table.table tbody tr:hover td,.dark-mode table.dataTable tbody tr:hover td{background:#334155!important}
.dark-mode input.form-control,.dark-mode select.form-control,.dark-mode textarea.form-control{background:#334155!important;color:#e2e8f0!important;border-color:rgba(255,255,255,0.12)!important}
.dark-mode .select2-container .select2-selection--single,.dark-mode .select2-container .select2-selection--multiple{background:#334155!important;border-color:rgba(255,255,255,0.12)!important}
.dark-mode .select2-container .select2-selection--single .select2-selection__rendered{color:#e2e8f0!important}
.dark-mode .select2-dropdown{background:#1e293b!important;border-color:rgba(255,255,255,0.1)!important;color:#e2e8f0!important}
.dark-mode .select2-results__option{color:#cbd5e1!important}
.dark-mode .select2-results__option--highlighted{background:#334155!important;color:#fff!important}
.dark-mode .small-box{background:#1e293b!important;border:1px solid rgba(255,255,255,0.07)!important}
.dark-mode .modal-content{background:#1e293b!important;color:#e2e8f0!important}
.dark-mode .modal-header{border-bottom-color:rgba(255,255,255,0.1)!important}
.dark-mode .modal-footer{border-top-color:rgba(255,255,255,0.1)!important}
.dark-mode .dropdown-menu{background:#1e293b!important;border-color:rgba(255,255,255,0.1)!important}
.dark-mode .dropdown-menu>li>a{color:#cbd5e1!important}
.dark-mode .dropdown-menu>li>a:hover{background:#334155!important}
/* Dark mode toggle icons */
#dark-mode-toggle .dm-sun{display:inline-block}
#dark-mode-toggle .dm-moon{display:none}
body.dark-mode #dark-mode-toggle .dm-sun{display:none}
body.dark-mode #dark-mode-toggle .dm-moon{display:inline-block}
</style>
<script>
// Apply dark mode immediately from localStorage to avoid flash
if(localStorage.getItem('apex_dark_mode')==='1'){document.documentElement.classList.add('dark-mode-loading');document.body && document.body.classList.add('dark-mode');}
</script>
<!-- Mobile Responsive -->
<link rel="stylesheet" href="{{ asset('css/mobile-responsive.css?v='.$asset_v) }}">

@if(isset($pos_layout) && $pos_layout)
	<link rel="stylesheet" href="{{ asset('css/pos-material.css?v='.$asset_v) }}">
	<link rel="stylesheet" href="{{ asset('css/pos-redesign.css?v=' . time()) }}">
@endif

<style type="text/css">
/* Disabled conflicting global overrides to allow redesign to take full effect
    .product_row td, 
    ...
*/
</style>
<style type="text/css">
	/*
	* Pattern lock css
	* Pattern direction
	* http://ignitersworld.com/lab/patternLock.html
	*/
	.patt-wrap {
	  z-index: 10;
	}
	.patt-circ.hovered {
	  background-color: #cde2f2;
	  border: none;
	}
	.patt-circ.hovered .patt-dots {
	  display: none;
	}
	.patt-circ.dir {
	  background-image: url("{{asset('/img/pattern-directionicon-arrow.png')}}");
	  background-position: center;
	  background-repeat: no-repeat;
	}
	.patt-circ.e {
	  -webkit-transform: rotate(0);
	  transform: rotate(0);
	}
	.patt-circ.s-e {
	  -webkit-transform: rotate(45deg);
	  transform: rotate(45deg);
	}
	.patt-circ.s {
	  -webkit-transform: rotate(90deg);
	  transform: rotate(90deg);
	}
	.patt-circ.s-w {
	  -webkit-transform: rotate(135deg);
	  transform: rotate(135deg);
	}
	.patt-circ.w {
	  -webkit-transform: rotate(180deg);
	  transform: rotate(180deg);
	}
	.patt-circ.n-w {
	  -webkit-transform: rotate(225deg);
	   transform: rotate(225deg);
	}
	.patt-circ.n {
	  -webkit-transform: rotate(270deg);
	  transform: rotate(270deg);
	}
	.patt-circ.n-e {
	  -webkit-transform: rotate(315deg);
	  transform: rotate(315deg);
	}
</style>
@if(!empty($__system_settings['additional_css']))
    {!! $__system_settings['additional_css'] !!}
@endif

{{-- ═══════════════════════════════════════════════════════════════
     GLOBAL MODAL REDESIGN — applies to all ~100 modals at once
     No individual modal files need changing.
     ═══════════════════════════════════════════════════════════════ --}}
<style>
/* ── Backdrop ─────────────────────────────────────────────────── */
.modal-backdrop.in { opacity: .55; }

/* ── Entrance animation ───────────────────────────────────────── */
@keyframes apexModalIn {
    from { opacity:0; transform:translateY(-18px) scale(.97); }
    to   { opacity:1; transform:translateY(0)     scale(1);   }
}
.modal.in .modal-dialog {
    animation: apexModalIn .22s cubic-bezier(.22,.61,.36,1) both;
}

/* ── Modal sizing — keep them compact ─────────────────────────── */
.modal-dialog               { max-width: 580px  !important; width: auto !important; }
.modal-dialog.modal-sm      { max-width: 380px  !important; }
.modal-dialog.modal-lg      { max-width: 720px  !important; }
.modal-dialog.modal-xl      { max-width: 820px  !important; }
@media (max-width: 767px) {
    .modal-dialog,
    .modal-dialog.modal-sm,
    .modal-dialog.modal-lg,
    .modal-dialog.modal-xl  { max-width: calc(100% - 20px) !important; width: calc(100% - 20px) !important; }
}

/* ── Shell ────────────────────────────────────────────────────── */
.modal-content {
    border: none !important;
    border-radius: 12px !important;
    overflow: hidden !important;
    box-shadow: 0 20px 60px rgba(0,0,0,.18), 0 4px 16px rgba(0,0,0,.1) !important;
}

/* ── Header ───────────────────────────────────────────────────── */
.modal-header {
    /* No !important on background — inline style= colors on specific modals will win */
    background: linear-gradient(135deg, var(--theme-dark, #3730a3) 0%, var(--theme-main, #4f46e5) 100%);
    color: #fff !important;
    padding: 16px 20px !important;
    border-bottom: none !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    min-height: 0 !important;
}
/* keep the existing modal-header-material (quick add product) intact */
.modal-header-material {
    background: linear-gradient(135deg, var(--theme-dark, #3730a3) 0%, var(--theme-main, #4f46e5) 100%);
    padding: 16px 20px !important;
    border-bottom: none !important;
}

.modal-header .modal-title,
.modal-header h3.modal-title,
.modal-header h4.modal-title {
    color: #fff !important;
    font-size: 15px !important;
    font-weight: 600 !important;
    margin: 0 !important;
    line-height: 1.4 !important;
    letter-spacing: .01em;
    display: flex;
    align-items: center;
    gap: 8px;
}
.modal-header .modal-title i.fa,
.modal-header .modal-title i.fas,
.modal-header .modal-title i.far {
    opacity: .85;
    font-size: 14px;
}

/* ── Close button ─────────────────────────────────────────────── */
.modal-header .close {
    color: rgba(255,255,255,.8) !important;
    opacity: 1 !important;
    text-shadow: none !important;
    font-size: 22px !important;
    font-weight: 300 !important;
    line-height: 1 !important;
    padding: 0 !important;
    margin: 0 !important;
    background: none !important;
    border: none !important;
    float: none !important;
    order: 2;
    cursor: pointer;
    transition: color .15s, transform .15s;
}
.modal-header .close:hover {
    color: #fff !important;
    transform: scale(1.15);
}

/* ── Body ─────────────────────────────────────────────────────── */
.modal-body {
    padding: 22px 24px !important;
    background: #fff;
    max-height: calc(100vh - 180px);
    overflow-y: auto;
}
/* section dividers inside modals */
.modal-body hr {
    border-color: #e9ecef;
    margin: 16px 0;
}
.modal-body h5 {
    font-size: 11px;
    font-weight: 700;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: .06em;
    margin: 16px 0 10px;
}
.modal-body h4 {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 12px;
}

/* ── Footer ───────────────────────────────────────────────────── */
.modal-footer {
    background: #f8fafc !important;
    border-top: 1px solid #e9ecef !important;
    padding: 12px 20px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: flex-end !important;
    gap: 8px !important;
}
.modal-footer .btn + .btn { margin-left: 0 !important; }

/* ── Form elements inside modals ──────────────────────────────── */
.modal-body .form-control {
    border-radius: 6px !important;
    border-color: #d1d5db !important;
    font-size: 13px !important;
    height: 34px !important;
    transition: border-color .15s, box-shadow .15s !important;
}
.modal-body textarea.form-control { height: auto !important; }
.modal-body .form-control:focus {
    border-color: var(--theme-main, #4f46e5) !important;
    box-shadow: 0 0 0 3px var(--theme-ring, #a5b4fc33) !important;
    outline: none !important;
}
.modal-body .form-group { margin-bottom: 14px !important; }
.modal-body .form-group label {
    font-size: 12px !important;
    font-weight: 600 !important;
    color: #374151 !important;
    margin-bottom: 4px !important;
    display: block;
}
.modal-body .input-group-addon {
    border-radius: 6px 0 0 6px !important;
    border-color: #d1d5db !important;
    background: #f3f4f6 !important;
    color: #6b7280 !important;
    font-size: 13px !important;
}

/* ── Buttons — standardise the footer actions ─────────────────── */
.modal-footer .btn,
.modal-body .modal-form-actions .btn {
    font-size: 13px !important;
    font-weight: 500 !important;
    border-radius: 6px !important;
    padding: 6px 16px !important;
    transition: background .15s, box-shadow .15s, transform .1s !important;
}
.modal-footer .btn:active { transform: scale(.97); }

/* primary action: use theme colour */
.modal-footer .btn-primary,
.modal-footer .btn-success,
.modal-footer .btn-info {
    background: var(--theme-main, #4f46e5) !important;
    border-color: var(--theme-main, #4f46e5) !important;
    color: #fff !important;
}
.modal-footer .btn-primary:hover,
.modal-footer .btn-success:hover,
.modal-footer .btn-info:hover {
    background: var(--theme-hover, #4338ca) !important;
    border-color: var(--theme-hover, #4338ca) !important;
    box-shadow: 0 4px 12px rgba(0,0,0,.15) !important;
}

/* cancel/secondary */
.modal-footer .btn-default {
    background: #fff !important;
    border-color: #d1d5db !important;
    color: #374151 !important;
}
.modal-footer .btn-default:hover {
    background: #f3f4f6 !important;
}

/* danger stays red */
.modal-footer .btn-danger {
    background: #dc2626 !important;
    border-color: #dc2626 !important;
    color: #fff !important;
}
.modal-footer .btn-danger:hover { background: #b91c1c !important; border-color:#b91c1c !important; }

/* warning */
.modal-footer .btn-warning {
    background: #d97706 !important;
    border-color: #d97706 !important;
    color: #fff !important;
}
.modal-footer .btn-warning:hover { background: #b45309 !important; border-color:#b45309 !important; }

/* ── Loading spinner inside modals ────────────────────────────── */
.modal-body .ajax-loading-container {
    text-align: center;
    padding: 40px 20px;
    color: #94a3b8;
}

/* ── Tab panes inside modals ──────────────────────────────────── */
.modal-body .nav-tabs { border-bottom: 2px solid #e5e7eb !important; margin-bottom: 16px; }
.modal-body .nav-tabs > li > a {
    font-size: 13px !important;
    font-weight: 500 !important;
    color: #6b7280 !important;
    border: none !important;
    padding: 8px 14px !important;
    border-radius: 0 !important;
    margin-bottom: -2px;
}
.modal-body .nav-tabs > li.active > a,
.modal-body .nav-tabs > li > a:hover {
    color: var(--theme-main, #4f46e5) !important;
    border-bottom: 2px solid var(--theme-main, #4f46e5) !important;
    background: none !important;
}

/* ── Scrollbar inside modal body ──────────────────────────────── */
.modal-body::-webkit-scrollbar { width: 5px; }
.modal-body::-webkit-scrollbar-track { background: transparent; }
.modal-body::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }

/* ── Dark mode ────────────────────────────────────────────────── */
.dark-mode .modal-content { background: #1e293b !important; }
.dark-mode .modal-body { background: #1e293b !important; color: #e2e8f0 !important; }
.dark-mode .modal-body h4,
.dark-mode .modal-body h5 { color: #94a3b8 !important; }
.dark-mode .modal-body hr { border-color: rgba(255,255,255,.08) !important; }
.dark-mode .modal-footer { background: #0f172a !important; border-top-color: rgba(255,255,255,.08) !important; }
.dark-mode .modal-footer .btn-default { background:#334155!important; border-color:rgba(255,255,255,.15)!important; color:#e2e8f0!important; }
.dark-mode .modal-body .form-group label { color: #94a3b8 !important; }
.dark-mode .modal-body .nav-tabs { border-bottom-color: rgba(255,255,255,.1) !important; }
.dark-mode .modal-body .nav-tabs > li > a { color: #94a3b8 !important; }

/* ── Responsive: full-screen on mobile ────────────────────────── */
@media (max-width: 767px) {
    .modal-dialog {
        margin: 10px auto !important;
        width: calc(100% - 20px) !important;
    }
    .modal-content { border-radius: 10px !important; }
    .modal-body { max-height: calc(100vh - 140px); }
    .modal-footer { flex-wrap: wrap; }
    .modal-footer .btn { flex: 1; text-align: center; }
}
</style>

{{-- SIDEBAR LOCK — must win over everything including system additional_css --}}
<style>
.side-bar {
    background: linear-gradient(180deg,#0f172a 0%,#1e293b 100%) !important;
    border-right: 1px solid rgba(255,255,255,0.06) !important;
}
.side-bar a,
.side-bar .sidebar-nav-link,
.side-bar .sidebar-child-link {
    color: rgba(255,255,255,0.72) !important;
}
.side-bar .sidebar-nav-link.active-item,
.side-bar a[style*="border-left:3px solid"] {
    color: #ffffff !important;
}
</style>

{{-- GLOBAL TABLE STYLE — loaded last, beats everything --}}
<style>
/* ─── Table reset ─────────────────────────────────────────── */
table.table,
table.dataTable,
.dataTables_wrapper table {
    border: none !important;
    border-collapse: collapse !important;
    border-spacing: 0 !important;
    border-radius: 0 !important;
    box-shadow: none !important;
    background: #fff !important;
    font-size: 13px !important;
}

/* ─── Header ──────────────────────────────────────────────── */
table.table thead th,
table.table thead td,
table.dataTable thead th,
table.dataTable thead td,
.dataTables_wrapper table thead th,
.dataTables_wrapper table thead td {
    background: #f8fafc !important;
    color: #64748b !important;
    font-size: 10px !important;
    font-weight: 700 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.06em !important;
    padding: 6px 10px !important;
    border: none !important;
    border-bottom: 2px solid #e2e8f0 !important;
    white-space: nowrap;
}

/* ─── Body cells ──────────────────────────────────────────── */
table.table tbody td,
table.table tbody th,
table.dataTable tbody td,
table.dataTable tbody th,
.dataTables_wrapper table tbody td {
    padding: 5px 10px !important;
    border: none !important;
    border-bottom: 1px solid #f1f5f9 !important;
    vertical-align: middle !important;
    font-size: 13px !important;
    line-height: 1.4 !important;
}

/* ─── Last row: no divider ────────────────────────────────── */
table.table tbody tr:last-child td,
table.table tbody tr:last-child th,
table.dataTable tbody tr:last-child td {
    border-bottom: none !important;
}

/* ─── No striping ─────────────────────────────────────────── */
table.table tbody tr,
table.table tbody tr:nth-child(odd),
table.table tbody tr:nth-child(even),
table.table-striped tbody tr:nth-of-type(odd),
table.table-striped tbody tr:nth-of-type(even),
table.dataTable tbody tr,
table.dataTable tbody tr:nth-child(odd),
table.dataTable tbody tr:nth-child(even),
.dataTables_wrapper table tbody tr,
.dataTables_wrapper table tbody tr:nth-child(odd),
.dataTables_wrapper table tbody tr:nth-child(even) {
    background: #ffffff !important;
}

/* ─── Hover ───────────────────────────────────────────────── */
table.table tbody tr:hover td,
table.table tbody tr:hover th,
table.dataTable tbody tr:hover td,
.dataTables_wrapper table tbody tr:hover td {
    background: #f8fafc !important;
}

/* ─── Footer ──────────────────────────────────────────────── */
table.table tfoot th,
table.table tfoot td,
table.dataTable tfoot th,
table.dataTable tfoot td {
    background: #f8fafc !important;
    font-weight: 600 !important;
    font-size: 13px !important;
    padding: 5px 10px !important;
    border: none !important;
    border-top: 2px solid #e2e8f0 !important;
}

/* ─── Remove all borders from bordered variant ────────────── */
table.table-bordered td,
table.table-bordered th {
    border: none !important;
    border-bottom: 1px solid #f1f5f9 !important;
}

/* ─── Card Headers & Titles (Pure White) ───────────────── */
.box-header, .card-header, .box-title, .card-title, 
[class*="box-header"], [class*="card-header"],
.box-header *, .card-header *, .box-title, .card-title {
    color: #ffffff !important;
}

/* ─── Export Buttons & Column Visibility (Perfect Alignment) ─── */
.dt-buttons {
    margin-bottom: 0.75rem !important;
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 4px !important;
    align-items: center !important;
}
/* Completely neutralize AdminLTE btn-group for export area */
.dt-buttons .btn-group, .dt-buttons .btn-group-vertical {
    display: contents !important; /* Makes the wrapper "disappear" so children align directly */
}
/* Uniform sizing for ALL button variants */
.dt-buttons .dt-button,
.dt-buttons .btn,
.buttons-colvis,
.buttons-csv,
.buttons-excel,
.buttons-pdf,
.buttons-print,
button.buttons-colvis,
a.buttons-colvis {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    height: 30px !important;
    min-height: 30px !important;
    max-height: 30px !important;
    line-height: 1 !important;
    padding: 0 12px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    border-radius: 4px !important;
    border: none !important;
    margin: 0 !important;
    box-sizing: border-box !important;
    text-transform: none !important;
}
.dt-buttons .buttons-colvis,
button.buttons-colvis,
a.buttons-colvis {
    background: #14b8a6 !important; /* Teal */
    color: #ffffff !important;
}
.dt-buttons .buttons-colvis:hover,
button.buttons-colvis:hover {
    background: #0d9488 !important;
}

/* ─── Pagination: Clean Prev / [1] / Next ────────────────── */
.dataTables_wrapper .dataTables_paginate {
    border: none !important;
    background: none !important;
    padding: 0 !important;
    margin: 15px 0 !important;
    box-shadow: none !important;
}
.dataTables_wrapper .dataTables_paginate .pagination {
    border: none !important;
    background: none !important;
    margin: 0 !important;
    padding: 0 !important;
    display: flex !important;
    gap: 4px !important;
    box-shadow: none !important;
}
/* Force hide all standard page numbers */
.dataTables_wrapper .dataTables_paginate .pagination > li {
    display: none !important;
}
/* Force show only the functional buttons */
.dataTables_wrapper .dataTables_paginate .pagination > li.previous,
.dataTables_wrapper .dataTables_paginate .pagination > li.next,
.dataTables_wrapper .dataTables_paginate .pagination > li.active {
    display: flex !important;
}
/* Pagination Button Styling (Matches CSV button height) */
.dataTables_wrapper .dataTables_paginate .pagination > li > a,
.dataTables_wrapper .dataTables_paginate .pagination > li > span {
    height: 30px !important;
    min-width: 32px !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    padding: 0 10px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    border-radius: 4px !important;
    border: none !important;
    background: var(--theme-main, #4f46e5) !important;
    color: #ffffff !important;
    margin: 0 !important;
    text-decoration: none !important;
}
/* Active (Current Page) - plain label, no box */
.dataTables_wrapper .dataTables_paginate .pagination > li.active > a,
.dataTables_wrapper .dataTables_paginate .pagination > li.active > span {
    background: transparent !important;
    color: var(--theme-main, #4f46e5) !important;
    border: none !important;
    cursor: default !important;
    pointer-events: none !important;
}
/* Hover effect for clickable pages */
.dataTables_wrapper .dataTables_paginate .pagination > li:not(.active):not(.disabled) > a:hover {
    background: var(--theme-hover, #4338ca) !important;
}
/* Disabled buttons - fully inert */
.dataTables_wrapper .dataTables_paginate .pagination > li.disabled > a,
.dataTables_wrapper .dataTables_paginate .pagination > li.disabled > span {
    opacity: 0.35 !important;
    background: #94a3b8 !important;
    cursor: not-allowed !important;
    pointer-events: none !important;
}

/* ─── Compact action button for datatables ───────────────── */
button.product-action-btn,
.product-action-btn.btn,
.product-action-btn {
    padding: 1px 7px !important;
    font-size: 10px !important;
    line-height: 1.5 !important;
    border-radius: 4px !important;
    box-shadow: none !important;
    transform: none !important;
    font-weight: 500 !important;
    height: auto !important;
    min-height: 0 !important;
}

/* ─── DataTables: Show X entries select ──────────────────── */
.dataTables_wrapper .dataTables_length {
    display: flex !important;
    align-items: center !important;
    gap: 6px !important;
}
.dataTables_wrapper .dataTables_length label {
    display: flex !important;
    align-items: center !important;
    gap: 6px !important;
    flex-wrap: nowrap !important;
    margin: 0 !important;
    white-space: nowrap !important;
}
.dataTables_wrapper .dataTables_length select,
.dataTables_wrapper .dataTables_length select.form-control {
    width: auto !important;
    min-width: 0 !important;
    max-width: none !important;
    display: inline-block !important;
    flex-shrink: 0 !important;
    height: 32px !important;
    padding: 0 8px !important;
    font-size: 13px !important;
    line-height: 1 !important;
    border: 1.5px solid #e2e8f0 !important;
    border-radius: 6px !important;
    background: #fff !important;
    box-shadow: none !important;
    cursor: pointer !important;
    appearance: auto !important;
    -webkit-appearance: auto !important;
}

/* ─── Global input/select/textarea text visibility fix ───── */
/* Prevents dark-background themed CSS from swallowing typed text */
input.form-control,
select.form-control,
textarea.form-control,
input[type="text"],
input[type="number"],
input[type="email"],
input[type="password"],
input[type="date"],
input[type="search"],
input[type="tel"],
input[type="url"],
.select2-selection,
.select2-container .select2-selection--single,
.select2-container .select2-selection--multiple,
.select2-search__field,
.input-group .form-control {
    background-color: #ffffff !important;
    color: #111827 !important;
    border-color: #d1d5db !important;
}
input.form-control::placeholder,
input[type="text"]::placeholder,
textarea.form-control::placeholder {
    color: #9ca3af !important;
}
input.form-control:focus,
select.form-control:focus,
textarea.form-control:focus {
    background-color: #ffffff !important;
    color: #111827 !important;
    border-color: var(--theme-main, #059669) !important;
    box-shadow: 0 0 0 2px rgba(5, 150, 105, 0.15) !important;
}
.select2-container .select2-selection--single .select2-selection__rendered {
    color: #111827 !important;
    line-height: 34px !important;
    padding-left: 10px !important;
    padding-right: 28px !important;
}
.select2-container .select2-selection--single {
    height: 34px !important;
    display: flex !important;
    align-items: center !important;
}
.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 34px !important;
    top: 0 !important;
}
.form-control {
    height: 34px;
    line-height: 34px;
    padding-top: 0;
    padding-bottom: 0;
    display: flex;
    align-items: center;
}
select.form-control {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    line-height: 34px !important;
}
textarea.form-control {
    height: auto;
    line-height: 1.5;
    display: block;
}
.select2-dropdown {
    background: #ffffff !important;
    color: #111827 !important;
}
.select2-results__option {
    color: #111827 !important;
}
.select2-results__option--highlighted {
    background-color: var(--theme-subtle, #ecfdf5) !important;
    color: var(--theme-dark, #065f46) !important;
}

/* ─── Mobile: prevent dark overlay on sidebar toggle tap ─── */
.sidebar-overlay,
.control-sidebar-bg,
body.sidebar-open::after {
    display: none !important;
}
@media (max-width: 991px) {
    .main-sidebar { z-index: 1050; }
    body.sidebar-open .content-wrapper,
    body.sidebar-open .main-header { opacity: 1 !important; pointer-events: auto !important; }
}
</style>

